import { environment } from './../../../../environments/environment.prod';
import { Component, ViewEncapsulation, OnInit, ViewChild, ElementRef } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from '@angular/router';
import { SelectItem, MenuItem, Message } from 'primeng/api';
import { QuoteModel } from "../../model/quote.model";
import { Address, Material, MaterialOrder, location, Budget, ActualProjectLevel, ProjectModel } from "../../model/project.model";
import { Helpers } from "../../../../app/helpers"
import { ProjectService } from "./project.service";
import * as _ from "lodash";
import swal from 'sweetalert2';
import { CommonService } from "../../../base/_services/common.service";
import { Variation } from "../../model/project.model";
import { Subject } from "rxjs/Subject";
import { ActiveQuotes } from "../../model/activeQuotes";


@Component({
  templateUrl: 'project.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./project.component.css']
})

export class ProjectComponent implements OnInit {
  constructor(private http: HttpClient, private _router: Router,
    private projectService: ProjectService, private commonService: CommonService) {
      this.baseUrl = environment.api_base.apiBase;
  }
  selectedProject: ProjectModel;
  profitePercent = 0;
  variations: Variation;
  employeeListArray: any = [];
  activeQuotes: QuoteModel[] = [];
  projectList: ProjectModel[] = [];
  step1_projectform = false;
  step2_jobprestart = false;
  step3_budget = false;
  step4_variations = false;
  step5_material = false;
  isComplete = false;
  @ViewChild('docForm') el: ElementRef;
  projectTable = true;
  items: MenuItem[];
  selectedQuote: QuoteModel;
  msgs: Message[] = [];
  activeIndex: number = 0;
  activeQuoteList: ActiveQuotes[] = [];
  activeQuote: ActiveQuotes;
  baseUrl: string;
  //materialList: Material[] = [];
  //materialOrderList: MaterialOrder[] = [];
  uploadedFiles: any = {
    swms: [],
    sds: [],
    other: [],
    drawing: [],
    finishes: [],
    risk: []
  };
  today = Date.now();
  actualProjectLevel: ActualProjectLevel = new ActualProjectLevel();
  destroy$: Subject<boolean> = new Subject<boolean>();


  ngOnInit() {
    debugger;
    this.selectedProject = new ProjectModel('');
    this.selectedProject.address = new Address();
    this.setSteps();
    //this.loadEmployee();

    this.http.get(this.baseUrl + 'api/quote/list').subscribe(quoteData => {
      // console.log("Quotes Data : " + JSON.stringify(quoteData));
      this.activeQuoteList = <ActiveQuotes[]>quoteData;
      // alert("ActiveQuoteList : " +JSON.stringify(this.activeQuoteList));
    });
    debugger;
  }
  // #region Old ngOnInit
  // this.projectService.updateEmployee.takeUntil(this.destroy$).subscribe(res => this.updateEmployee(res));
  // this.http.get(this.baseUrl + 'api/quote').subscribe(quoteData => {
  //     this.http.get(this.baseUrl + 'api/project').subscribe(projectData => {
  //         this.projectList = <ProjectModel[]>projectData;
  //         this.projectService.projects = this.projectList;
  //         let quotes: QuoteModel[] = <QuoteModel[]>quoteData;
  //         this.activeQuotes = quotes.filter(q => q.outcome == 'Success');
  //         this.activeQuotes = this.activeQuotes.map(q => {
  //             q.projectStatus = 'Incomplete';
  //             if (this.projectList.filter(p => p.quoteId == q._id).length) {
  //                 q.projectStatus = 'Complete';
  //             }
  //             return q;
  //         })
  //     });
  // });

  // let data = this.getData();
  // for (var i = data.length - 1; i >= 0; i--) {
  //     if (data[i]['status'] == 'Complete')
  //         this.quotes.push(data[i]);
  // }
  // #endregion

  ngOnDestroy() {
    this.destroy$.next(true);
    // Now let's also unsubscribe from the subject itself:
    this.destroy$.unsubscribe();
  }

  updateEmployee(data) {
    debugger;
    this.employeeListArray.push('');
    this.employeeListArray[data.index] = data.employees.map(emp => {
      return { label: emp.name, value: emp.name }
    });
    this.selectedProject.locations[data.index].employees = data.employees.map(emp => emp['_id']);
  }
  setSteps() {
    this.items = [{
      label: 'Project',
      command: (event: any) => {
        this.next(0);
        this.msgs.length = 0;
        this.msgs.push({ severity: 'info', summary: 'View Project Details', detail: event.item.label });
      }
    },
    {
      label: 'Job Prestart',
      command: (event: any) => {
        this.msgs.length = 0;
        this.next(1);
        this.msgs.push({ severity: 'info', summary: 'Upload Project Documents', detail: event.item.label });
      }
    },
    {
      label: 'Budget',
      command: (event: any) => {
        this.msgs.length = 0;
        this.next(2);
        this.msgs.push({ severity: 'info', summary: 'Fill the project cost', detail: event.item.label });
      }
    },
    {
      label: 'Variation',
      command: (event: any) => {
        this.msgs.length = 0;
        this.next(3);
        this.msgs.push({ severity: 'info', summary: 'Variation', detail: event.item.label });
        // if (this.selectedProject.variation.length == 0) {
        //     this.addVariation();
        // }
      }
    },
    {
      label: 'Material Order',
      command: (event: any) => {
        this.activeIndex = 4;
        this.msgs.length = 0;
        this.next(4);
        this.msgs.push({ severity: 'info', summary: 'Add the material order', detail: event.item.label });
        this.selectedProject.materialOrders.length == 0 && this.addMaterialOrder();
      }
    }
    ];
  }
  submit() {
    this.selectedProject.status = 'Complete';
    this.http.post(this.baseUrl + 'api/project', this.selectedProject).subscribe(data => {
      console.log('project', data);
      this.ngOnInit();
      this.step1_projectform = false;
      this.step5_material = false;
      this.projectTable = true;
      window.scrollTo(0, 0);
    });
  }
  next(key) {
    switch (key) {
      case 0:
        this.step1_projectform = true;
        this.step2_jobprestart = false;
        this.step3_budget = false;
        this.step4_variations = false;
        this.step5_material = false;
        this.activeIndex = 0;
        break;
      case 1:
        this.step1_projectform = false;
        this.step2_jobprestart = true;
        this.step3_budget = false;
        this.step4_variations = false;
        this.step5_material = false;
        this.activeIndex = 1;
        break;
      case 2:
        this.step1_projectform = false;
        this.step2_jobprestart = false;
        this.step3_budget = true;
        this.step4_variations = false;
        this.step5_material = false;
        this.activeIndex = 2;
        break;
      case 3:
        this.step1_projectform = false;
        this.step2_jobprestart = false;
        this.step3_budget = false;
        this.step4_variations = true;
        this.step5_material = false;
        this.activeIndex = 3;
        break;
      case 4:
        this.step1_projectform = false;
        this.step2_jobprestart = false;
        this.step3_budget = false;
        this.step4_variations = false;
        this.step5_material = true;
        this.activeIndex = 4;

        break;
      case 5:
        this.step1_projectform = false;
        this.step2_jobprestart = false;
        this.step3_budget = false;
        this.step4_variations = false;
        this.step5_material = false;
        this.activeIndex = 5;
        break;
      default:
        break;
    }

    window.scrollTo(0, 0);
  }
  shareMO(index) {
    this.projectService.moDetails = [this.selectedProject.materialOrders[index]];
  }
  addMaterial(index = 0) {
    this.selectedProject.materialOrders[index].material.push({ name: '', quantity: 0 });
  }
  addMaterialOrder() {
    this.selectedProject.materialOrders.push(new MaterialOrder(this.selectedProject.name));
  }

  addVariation() {
    this.selectedProject.variation.forEach(item => {
      item.collaps = true;
    })
    this.selectedProject.variation.push(new Variation(this.selectedProject.name));
  }
  saveVariation() {

  }
  openFile(path) {
    window.open(path);
  }
  // removevariationFile() {
  //     this.http.delete('api/project/variationupload/' + this.selectedProject.quoteId + '/' + this.selectedProject.variation[0].id).subscribe(res => {
  //         this.getVariationDocs();
  //     }
  // }
  removeVariation(index) {
    this.selectedProject.variation.splice(index, 1);
  }
  removeMO(index) {
    this.selectedProject.materialOrders.splice(index, 1);
  }
  variationToggle(id, index: number = 0) {
    this.getVariationDocs(id, index);
  }
  getVariationDocs(id, index: number = 0) {
    Helpers.setLoading(true);
    this.http.get(this.baseUrl + 'api/project/variationupload/' + this.selectedProject.quoteId + '/' + id).subscribe(res => {
      this.selectedProject.variation[index].variationFiles = <any>res;
      Helpers.setLoading(false);
    })
  }
  getMODocs(id, index: number = 0) {
    Helpers.setLoading(true);
    this.http.get(this.baseUrl + 'api/project/moinvoiceupload/' + this.selectedProject.quoteId + '/' + id).subscribe(res => {
      this.selectedProject.materialOrders[index].invoiceFiles = <any>res;
      Helpers.setLoading(false);
    })
  }
  onvariationUpload(event, id, index: number = 0) {
    this.getVariationDocs(id, index);
  }
  onMOUpload(event, id, index: number = 0) {
    this.getMODocs(id, index);
  }

  onUpload(event, type) {
    debugger;
    this.setUploadDocumentsToVIew(this.selectedQuote);
    // for (let file of event.files) {
    //     if (file.objectURL) {
    //         this.uploadedFiles[type].push({ clientPath: file.objectURL.changingThisBreaksApplicationSecurity, name: file.name });
    //     } else {
    //         this.setUploadDocumentsToVIew(this.selectedQuote);
    //         //this.uploadedFiles[type].push({ name: file.name });
    //     }
    // }
    // let postObj = {
    //     file: this.uploadedFiles,
    //     quoteId: this.selectedProject.quoteId
    // }
    // this.http.post("api/project/upload", postObj).subscribe(res => {
    // })
    this.msgs = [];
    this.msgs.push({ severity: 'info', summary: 'File Uploaded', detail: '' });
  }
  changeApproval(index) {

  }
  onFileSelect(event) {
    debugger;
  }

  viewFile(file) {
    let clientPath = file.clientPath || "";
    if (clientPath) {
      window.open(clientPath);
      return;
    }
    window.open(file.path.replace('/app/dist/public', ''));
    return false;
  }
  removeFile(file) {
    debugger;
    this.http.post("api/project/removeFile", file).subscribe(res => {
      debugger;
      this.setUploadDocumentsToVIew(this.selectedQuote);
    })

  }
  removeVariationFile(file, id, index: number = 0) {
    Helpers.setLoading(true);
    this.http.post("api/project/removeFile", file).subscribe(res => {
      this.getVariationDocs(id, index);
    })

  }

  removeMOFile(file, id, index: number = 0) {
    Helpers.setLoading(true);
    this.http.post("api/project/removeFile", file).subscribe(res => {
      this.getVariationDocs(id, index);
    })

  }
  setUploadDocumentsToVIew(quote) {
    Helpers.setLoading(true);
    this.http.post("api/project/getFiles", { quoteId: quote['_id'] })
      .subscribe(response => {
        this.projectService.FileObj = response;
        this.uploadedFiles = response;
        Helpers.setLoading(false);
      })
  }
  trackByFn(index, item) {
    return index
  }
  addAddress() {
    if (this.selectedProject.locations.length) {
      let isEmpSelect = this.selectedProject.locations[this.selectedProject.locations.length - 1].employees.length > 0;
      if (!isEmpSelect) {
        swal({ text: 'Please Select Employees...' });
        return;
      }
    }
    this.selectedProject.locations.push(new location());
  }
  // #region Even Binding methods
  async onRowDblclick(quote) {
    this.activeQuote = quote;
    if (quote['projectStatus'] === 'Complete') {
      // alert('Not Allowed!!');
      this.isComplete = true;

      // get selected project details from server if project status= complete
      await this.http.get(this.baseUrl + 'api/project/' + this.activeQuote.projectId).subscribe(projectData => {
        this.selectedProject = <ProjectModel>projectData;
        // alert('Project Data ' + JSON.stringify(this.selectedProject));
      });
    } else {
      this.isComplete = false;
    }
    // get selected quote details from server
    await this.http.get(this.baseUrl + 'api/quote/selectedquote/' + this.activeQuote._id).subscribe(quoteData => {
      this.selectedQuote = <QuoteModel>quoteData;
      this.selectedProject.quote_date = this.selectedQuote.date;
      this.selectedProject.name = this.selectedQuote.name;
      this.selectedProject.scopeDetail = this.selectedQuote.scopeDetail;
      this.selectedProject.cost =  this.selectedQuote.totalCost;
      this.selectedProject.address = new Address();
      this.projectTable = false;
      this.step1_projectform = true;
    });
  }

  // #endregion
  // onRowDblclick(quote) {
  //   debugger;
  //   this.setUploadDocumentsToVIew(quote);
  //   this.selectedProject = new ProjectModel(quote['name']);
  //   if (quote) {
  //     this.selectedQuote = quote;
  //   } else {
  //     quote = this.selectedQuote;
  //   }
  //   if (quote['projectStatus'] == 'Complete') {
  //     //alert('Not Allowed!!');
  //     this.isComplete = true;

  //   } else {
  //     this.isComplete = false;

  //   }
  //   this.projectService.quoteId = this.selectedQuote._id;
  //   this.step1_projectform = true;
  //   this.projectTable = false;
  //   if (this.projectList.find(p => p.quoteId == quote['_id'])) {
  //     _.assign(this.selectedProject, this.projectList.find(p => p.quoteId == quote['_id']));
  //     return;
  //   }
  //   this.selectedProject.quote_date = quote['date'];
  //   this.selectedProject.quoteId = quote['_id'];

  //   this.selectedProject.name = quote['name'];
  //   this.selectedProject.scopeDetail = quote['scopeDetail'];
  //   this.selectedProject.cost = quote['totalCost'];
  //   this.selectedProject.address = new Address();
  // }
  cancel() {
    this.selectedProject = new ProjectModel('');
    this.step1_projectform = false;
    this.projectTable = true;
    this.selectedQuote = null;
    this.step1_projectform = false;
    this.step2_jobprestart = false;
    this.step3_budget = false;
    this.step4_variations = false;
    this.step5_material = false;
    this.activeIndex = 0;
    window.scrollTo(0, 0);
  }

  addBudget() {
    this.selectedProject.projectBudget.push(new Budget());
  }


  // loadEmployee() {
  //     this.commonService.getEmployee()
  //         .subscribe(res => {
  //             let elist = res.json().data;
  //             this.employeeList = elist.map(emp => {
  //                 return { label: 'Name: ' + emp.name + ' - Type: ' + emp.employeeTypeName, value: emp._id, type: emp.employeeTypeName };
  //             })
  //         },
  //             error => {
  //                 console.log('in error');
  //             });
  // }
  onLocationChange(location, index) {
    let uniqname = this.selectedProject.name + this.selectedProject.locations[index].location + Math.floor(Math.random() * (999 - 100 + 1) + 100);
    this.selectedProject.locations[index].locationCode = uniqname;
  }
  onChange(type, index = 0) {
    switch (type) {
      case 'blocationcode':
        debugger;
        let locObj = this.selectedProject.projectBudget[index];
        if (!locObj.locationCode) {
          this.selectedProject.projectBudget[index].location = '';
          break;
        }
        let lctn = this.selectedProject.locations.find(loc => locObj.locationCode == loc.locationCode);
        let MO = this.selectedProject.materialOrders.filter(mo => mo.location == lctn.locationCode);

        let mo = MO.map(m => {
          return m.supplierCost
        }).reduce((a, b) => a + b, 0);
        this.selectedProject.projectBudget[index].location = lctn.location;
        this.selectedProject.projectBudget[index].materialRate = mo;
        break;
      default:
        break;
    }
  }
  toggle(index, type, event) {
    debugger;
    switch (type) {
      case 'mo':
        if (!event.collapsed) {
          for (let i = 0; i < this.selectedProject.materialOrders.length; i++) {
            const element = this.selectedProject.materialOrders[i];
            if (i != index) {
              this.selectedProject.materialOrders[i].collaps = true;
            }
          }
        }
        break;

      default:
        break;
    }
  }
  calculateBudget(index = 0) {
    debugger;
    let currBudget = this.selectedProject.projectBudget[index];
    // alert('Project Budget ' + this.selectedProject.projectBudget[index]);
    this.selectedProject.projectBudget[index].totalPrice = currBudget.sqmperhr * currBudget.rate + currBudget.materialRate;
    if (index > 0) {
      this.selectedProject.projectBudget[index].totalBudget = this.selectedProject.projectBudget[index - 1].totalBudget - this.selectedProject.projectBudget[index].totalPrice;
    } else {
      this.selectedProject.projectBudget[index].totalBudget = +this.selectedProject.cost - this.selectedProject.profite - this.selectedProject.projectBudget[index].totalPrice;
    }
    this.actualProjectLevel.price = this.selectedProject.projectBudget.map(m => {
      return m.totalPrice
    }).reduce((a, b) => a + b, 0);
    debugger;
    this.actualProjectLevel.netProfit = this.actualProjectLevel.price - this.actualProjectLevel.ctc;
    //let pe = this.projectService.employeeList;
    let rates = this.selectedProject.locations.map(loc => {
      if (loc.employees.length) {
        loc.employees.filter(emp => {
          let emps = this.projectService.employeeList.find(allEmp => allEmp._id == emp);
          if (emps && emps.employeeTypeName == 'PAYG') {
            return { rate: emps.rate };
          }
        })
      }
      return { rate: 0 };
    });
    this.actualProjectLevel.ctc = rates.map(m => {
      return m.rate
    }).reduce((a, b) => a + b, 0);
    debugger;
    //this.actualProjectLevel.ctc
  }
}

class uploadedFile {
  swms: fileKey[];
  sds: fileKey[];
  other: fileKey[];
  drawing: fileKey[];
  finishes: fileKey[];
  risk: fileKey[];
}
class fileKey {
  name: string;
  path: string;
}

