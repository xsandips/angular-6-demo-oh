import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LayoutModule } from './../../layouts/layout.module';
import { DefaultComponent } from '../../pages/default/default.component';
import { ProjectComponent } from './project.component';
import { EmailModalComponent } from './email-modal/email-modal.component';
import { ProjectService } from './project.service';
import { DialogModule } from 'primeng/components/dialog/dialog';
import { CheckboxModule } from 'primeng/checkbox';
import { FieldsetModule } from 'primeng/fieldset';
import { TableModule } from 'primeng/table';
import { ListboxModule } from 'primeng/listbox';
import { MaterialmailComponent } from './materialOrderMail/mo.component';
import { AssignEmployeeComponent } from './employee/employee.component';

const routes: Routes = [
    {
        'path': '',
        'component': DefaultComponent,
        'children': [
            {
                'path': '',
                'component': ProjectComponent,
                children: [{
                    path: 'projectmail',
                    component: EmailModalComponent
                },
                {
                    path: 'employee/:index',
                    component: AssignEmployeeComponent
                },
                {
                    path: 'materialOrder',
                    component: MaterialmailComponent
                }]
            }

        ],
    },
];

@NgModule({
    imports: [
        CommonModule, RouterModule.forChild(routes), LayoutModule, DialogModule, CheckboxModule, ListboxModule, FieldsetModule, TableModule
    ], exports: [
        RouterModule,
    ], declarations: [
        ProjectComponent,
        EmailModalComponent,
        MaterialmailComponent,
        AssignEmployeeComponent
    ],
    providers: [ProjectService]
})
export class ProjectModule {
}