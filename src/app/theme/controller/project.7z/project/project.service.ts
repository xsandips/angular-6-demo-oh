import { Injectable } from '@angular/core';
import { MaterialOrder, ProjectModel } from '../../model/project.model';
import { Subject } from 'rxjs';

@Injectable()
export class ProjectService {
    private file: any;
    private MODetails: MaterialOrder[];
    private allProjectDetails: ProjectModel[];
    updateEmployee: Subject<any> = new Subject<any>();
    public employeeList = [];
    quoteId: string;
    get FileObj() {
        return this.file;
    }
    set FileObj(file) {
        this.file = file;
    }
    get moDetails() {
        return this.MODetails;
    }
    set moDetails(detail) {
        this.MODetails = detail;
    }
    get projects() {
        return this.allProjectDetails;
    }
    set projects(projects) {
        this.allProjectDetails = projects;
    }
}